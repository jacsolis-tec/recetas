<?php
// app/models/UserModel.php

// Ruta correcta: Sube dos niveles (../../) para llegar a config/
require_once __DIR__ . '/../../config/dbConfig.php';

class UserModel {
    private $db; // Usamos $this->db para la conexión PDO

    public function __construct() {
        try {
            // Usamos las constantes DB_SERVERNAME, DB_NAME, DB_USERNAME, DB_PASSWORD
            // (Estas constantes deben estar definidas en config/dbConfig.php)
            $dsn = 'mysql:host=' . DB_SERVERNAME . ';dbname=' . DB_NAME . ';charset=utf8';
            
            // Establecemos la conexión PDO
            $this->db = new PDO($dsn, DB_USERNAME, DB_PASSWORD);
            
            // MUY IMPORTANTE: Establecer el modo de error a EXCEPTION para poder usar try/catch
            $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
        } catch (PDOException $e) {
            // Si la conexión falla, detenemos la ejecución y mostramos el error
            die('Error de conexión a la base de datos: ' . $e->getMessage());
        }
    }

    /**
     * Busca un usuario por su nombre de usuario.
     * @param string $username El nombre de usuario a buscar.
     * @return array|false Los datos del usuario o false si no se encuentra.
     */
    public function findByUsername($username) {
        // Usamos DB_TABLE_NAME para el nombre de la tabla 'usuario'
        $sql = "SELECT id_usuario, nombre_usuario, password_hash, activo 
                 FROM " . DB_TABLE_NAME . " 
                 WHERE nombre_usuario = :username LIMIT 1";
        
        $stmt = $this->db->prepare($sql); 
        $stmt->bindParam(':username', $username);
        $stmt->execute();
        
        // Devolvemos el resultado como un array asociativo
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    /**
     * Inserta un nuevo usuario en la tabla 'usuario'.
     * @return bool|string True si la inserción fue exitosa, 'duplicate' si es clave única, false en caso contrario.
     */
    public function createUser($nombre_usuario, $nombre, $apellido, $correo, $password_hash) {
        $sql = "INSERT INTO " . DB_TABLE_NAME . " 
                (nombre_usuario, nombre, apellido, correo, password_hash)
                VALUES (:nombre_usuario, :nombre, :apellido, :correo, :password_hash)";
        
        try {
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':nombre_usuario', $nombre_usuario);
            $stmt->bindParam(':nombre', $nombre);
            $stmt->bindParam(':apellido', $apellido);
            $stmt->bindParam(':correo', $correo);
            $stmt->bindParam(':password_hash', $password_hash);
            
            // Si la ejecución es exitosa, devuelve TRUE
            return $stmt->execute(); 
            
        } catch (PDOException $e) {
            
            // 1. Verificar si es un error de clave duplicada (SQLSTATE 23000)
            if ($e->getCode() === '23000') { 
                return 'duplicate'; // <-- Retorna 'duplicate' al AuthController
            }
            
            // 2. Para otros errores (ej: un campo NOT NULL está vacío)
            // IMPORTANTE: Escribe el error completo al log de Apache para depuración.
            error_log("Database Error in createUser: " . $e->getMessage()); 
            return false; // Devuelve FALSE para errores desconocidos
        }
    }
}
?>