<?php
// app/models/AlmacenModel.php

class AlmacenModel {
    private $db;

    // Asumimos que Database::getInstance()->getConnection() devuelve la conexión PDO
    public function __construct(PDO $dbConnection) {
        $this->db = $dbConnection;
    }

    /**
     * Obtiene el listado completo del inventario actual, incluyendo el nombre del ingrediente.
     */
    public function getInventarioCompleto() {
        $sql = "
            SELECT 
                i.id_inventario, 
                ig.nombre_ingrediente, 
                i.stock_actual,
                u.nombre AS unidad_stock,
                i.stock_minimo
            FROM 
                inventario i
            JOIN 
                ingrediente ig ON i.id_ingrediente = ig.id_ingrediente
            JOIN 
                unidad u ON i.id_unidad = u.id_unidad
            ORDER BY 
                ig.nombre_ingrediente;
        ";
        $stmt = $this->db->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Registra una ENTRADA de stock y actualiza el inventario en una transacción.
     * @param int $id_inventario FK a la tabla inventario.
     * @param float $cantidad Cantidad que entra.
     * @param int $usuario_id ID del usuario que registra.
     * @param int $id_area_destino ID del área donde se almacena (ej: Bodega Principal=1).
     * @return bool
     */
    public function registrarEntradaStock($id_inventario, $cantidad, $usuario_id, $id_area_destino = 1, $observacion = null) {
        $this->db->beginTransaction(); // Iniciar transacción
        try {
            // 1. Registrar el movimiento de ENTRADA en mov_inventario
            $sql_mov = "
                INSERT INTO mov_inventario 
                (id_inventario, tipo_movimiento, cantidad, id_area_destino, id_usuario_registro, observacion) 
                VALUES (?, 'ENTRADA', ?, ?, ?, ?)
            ";
            $stmt_mov = $this->db->prepare($sql_mov);
            $stmt_mov->execute([$id_inventario, $cantidad, $id_area_destino, $usuario_id, $observacion]);

            // 2. Actualizar el stock actual en la tabla inventario
            $sql_update = "
                UPDATE inventario 
                SET stock_actual = stock_actual + ? 
                WHERE id_inventario = ?
            ";
            $stmt_update = $this->db->prepare($sql_update);
            $stmt_update->execute([$cantidad, $id_inventario]);

            $this->db->commit(); // Confirmar la transacción
            return true;
        } catch (Exception $e) {
            $this->db->rollBack(); // Deshacer los cambios si algo falla
            // En un entorno de producción, podrías usar error_log($e->getMessage());
            return false;
        }
    }
}