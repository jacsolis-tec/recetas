<?php
// Este modelo SOLO interactúa con la Base de Datos.
class VentaModel {
    private $db; // Objeto PDO

    public function __construct(PDO $dbConnection) {
        $this->db = $dbConnection; 
    }

    /**
     * Obtiene los datos necesarios para la venta (precio_venta y el id_historico).
     */
    public function getRecetaDetails($receta_id) {
        $sql = "SELECT id_receta_historico, nombre_receta, precio_venta 
                FROM receta_historico 
                WHERE id_receta_activa = :id_receta_activa
                ORDER BY version DESC 
                LIMIT 1";
        
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(':id_receta_activa', $receta_id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch();
    }

    /**
     * Registra el pedido final en las tablas 'venta' y 'venta_detalle'.
     */
    public function finalizeSale($cajero_id, $tipo_pago, $items, $total_venta) {
        // Lógica de transacción SQL (ver explicación en mensajes anteriores)
        $this->db->beginTransaction();

        try {
            // 1. Insertar en VENTA (Encabezado)
            $sql_venta = "INSERT INTO venta (id_usuario_cajero, fecha_venta, tipo_pago, total_venta) 
                          VALUES (?, NOW(), ?, ?)";
            $stmt_venta = $this->db->prepare($sql_venta);
            $stmt_venta->execute([$cajero_id, $tipo_pago, $total_venta]);
            $id_venta = $this->db->lastInsertId();

            // 2. Insertar en VENTA_DETALLE
            $sql_detalle = "INSERT INTO venta_detalle (id_venta, id_receta_historico, cantidad, precio_unitario) 
                            VALUES (?, ?, ?, ?)";
            $stmt_detalle = $this->db->prepare($sql_detalle);

            foreach ($items as $item) {
                $stmt_detalle->execute([
                    $id_venta, 
                    $item['id_receta_historico'], 
                    $item['qty'], 
                    $item['price']
                ]);
            }

            $this->db->commit();
            return true;
        } catch (Exception $e) {
            $this->db->rollBack();
            return false;
        }
    }
}
?>