<?php
// app/models/ReportesModel.php

class ReportesModel {
    private $db;

    public function __construct(PDO $dbConnection) {
        $this->db = $dbConnection;
    }

    /**
     * Reporte 1: Ventas por Período
     * Genera un resumen de ventas totales dentro de un rango de fechas.
     */
    public function getResumenVentas($fecha_inicio, $fecha_fin) {
        $sql = "
            SELECT 
                DATE(fecha_venta) AS dia, 
                COUNT(id_venta) AS total_ventas,
                SUM(total_venta) AS ingresos_totales
            FROM 
                venta
            WHERE 
                fecha_venta >= :inicio AND fecha_venta <= :fin
            GROUP BY 
                dia
            ORDER BY
                dia;
        ";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            ':inicio' => $fecha_inicio . ' 00:00:00',
            ':fin' => $fecha_fin . ' 23:59:59'
        ]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    /**
     * Reporte 2: Inventario Crítico (Bajo Stock Mínimo)
     * Basado en las tablas inventario, ingrediente y unidad.
     */
    public function getInventarioCritico() {
        $sql = "
            SELECT 
                ig.nombre_ingrediente,
                i.stock_actual,
                i.stock_minimo,
                u.nombre AS unidad
            FROM 
                inventario i
            JOIN 
                ingrediente ig ON i.id_ingrediente = ig.id_ingrediente
            JOIN 
                unidad u ON i.id_unidad = u.id_unidad
            WHERE 
                i.stock_actual < i.stock_minimo
            ORDER BY 
                i.stock_actual;
        ";
        $stmt = $this->db->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}