
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <title>Sistema POS - Versión HTML</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="<?php echo BASE_URL; ?>/styles.css" />
</head>
<body>
  <div class="app-shell">
    <aside class="sidebar">
      <div class="sidebar-header">
        <h1>Sistema POS</h1>
        <p class="sidebar-user">Usuario: <?php echo htmlspecialchars($username); ?></p>
      </div>
      <nav class="sidebar-nav">
        <button class="nav-item active" data-target="home">Inicio</button>
        <button class="nav-item" data-target="pos">Punto de Venta</button>
        <button class="nav-item" data-target="orders">Pedidos (Cocina)</button>
        <button class="nav-item" data-target="prepared">Preparados</button>
        <button class="nav-item" data-target="warehouse">Almacén</button>
        <button class="nav-item" data-target="reports">Reportes</button>
        <button class="nav-item" data-target="settings">Configuración</button>
      </nav>

      <form action="<?php echo BASE_URL; ?>/logout" method="POST" class="logout-form">
          <button type="submit" class="nav-item logout-btn">Cerrar Sesión</button>
      </form>
    </aside>

    <main class="main">
      <header class="main-header">
        <h2 id="page-title">Inicio</h2>
      </header>

      <section class="page visible" id="home">
        <div class="card">
          <h3>Bienvenido al Sistema del Comedor</h3>
          <ul class="simple-list">
            <li>Punto de Venta con listado de productos y carrito estático.</li>
            <li>Vista de Órdenes de producción (cocina).</li>
            <li>Gestión de Preparados.</li>
            <li>Gestión de Almacén / Insumos.</li>
            <li>Reportes con tarjetas e informes estáticos.</li>
          </ul>
        </div>
      </section>

      <!-- POS -->
      <section class="page" id="pos">
        <div class="page-grid">
          <div class="card">
            <h3>Productos</h3>
            <div class="toolbar">
              <input type="text" placeholder="Buscar producto..." class="input" />
            </div>
            <div class="products-grid">
              <article class="product-card">
                <div class="product-image"></div>
                <div class="product-body">
                  <h4>Ejemplo de Platillo</h4>
                  <p class="muted">Categoría: Platillo Principal</p>
                  <p class="muted small">Código: P-001</p>
                  <div class="badge-row">
                    <span class="badge badge-ok">Disponibles: 15 / 30</span>
                  </div>
                  <p class="price">₡2 500</p>
                  <div class="qty-row">
                    <button class="btn-outline">-</button>
                    <span class="qty-display">0</span>
                    <button class="btn-outline">+</button>
                  </div>
                  <button class="btn-primary full-width">Agregar al pedido</button>
                </div>
              </article>
              <article class="product-card">
                <div class="product-image low-stock"></div>
                <div class="product-body">
                  <h4>Bebida Fría</h4>
                  <p class="muted">Categoría: Bebidas</p>
                  <p class="muted small">Código: B-010</p>
                  <div class="badge-row">
                    <span class="badge badge-danger">Stock Bajo</span>
                  </div>
                  <p class="price">₡1 200</p>
                  <div class="qty-row">
                    <button class="btn-outline">-</button>
                    <span class="qty-display">0</span>
                    <button class="btn-outline">+</button>
                  </div>
                  <button class="btn-primary full-width">Agregar al pedido</button>
                </div>
              </article>
            </div>
          </div>

          <div class="card cart-card">
            <div class="cart-header">
              <h3>Pedido Actual</h3>
              <span class="badge">2 artículos</span>
            </div>
            <div class="cart-body scroll">
              <div class="cart-item">
                <div>
                  <p>Ejemplo de Platillo</p>
                  <p class="muted small">2 x ₡2 500</p>
                </div>
                <div class="cart-item-right">
                  <span>₡5 000</span>
                  <button class="icon-btn">🗑️</button>
                </div>
              </div>
              <div class="cart-item">
                <div>
                  <p>Bebida Fría</p>
                  <p class="muted small">1 x ₡1 200</p>
                </div>
                <div class="cart-item-right">
                  <span>₡1 200</span>
                  <button class="icon-btn">🗑️</button>
                </div>
              </div>
            </div>
            <div class="cart-footer">
              <div class="cart-total-row">
                <span>Total:</span>
                <span class="cart-total">₡6 200</span>
              </div>
              <div class="cart-actions">
                <button class="btn-ghost" id="clear-cart-btn">Limpiar</button>
                <button class="btn-primary" id="checkout-btn">Cobrar</button>
              </div>
            </div>
          </div>
        </div>
      </section>

      <!-- Orders (Cocina) -->
      <section class="page" id="orders">
        <div class="page-header-row">
          <h3>Órdenes de Producción - Cocina</h3>
          <button class="btn-primary" id="new-order-btn">Nueva Orden</button>
        </div>
        <div class="page-two-cols">
          <div class="card">
            <h4>Órdenes Pendientes</h4>
            <table class="table">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Producto</th>
                  <th>Cantidad Esperada</th>
                  <th>Estado</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>1</td>
                  <td>Arroz con Pollo</td>
                  <td>40 porciones</td>
                  <td><span class="badge badge-alert">Pendiente</span></td>
                </tr>
                <tr>
                  <td>2</td>
                  <td>Pasta con Salsa</td>
                  <td>30 porciones</td>
                  <td><span class="badge badge-progress">En preparación</span></td>
                </tr>
              </tbody>
            </table>
          </div>
          <div class="card">
            <h4>Últimas Órdenes Completadas</h4>
            <ul class="timeline">
              <li>
                <div class="timeline-title">Orden #10 - Casado Tradicional</div>
                <div class="muted small">Esperado: 50 / Real: 48 - Completada hoy</div>
              </li>
              <li>
                <div class="timeline-title">Orden #9 - Ensaladas Mixtas</div>
                <div class="muted small">Esperado: 30 / Real: 30 - Completada ayer</div>
              </li>
            </ul>
          </div>
        </div>
      </section>

      <!-- Prepared -->
      <section class="page" id="prepared">
        <div class="page-header-row">
          <h3>Gestión de Preparados</h3>
        </div>
        <div class="cards-grid-3">
          <div class="card stat">
            <p class="muted small">Total Productos</p>
            <p class="stat-value">24</p>
          </div>
          <div class="card stat">
            <p class="muted small">Stock Alto</p>
            <p class="stat-value ok">12</p>
          </div>
          <div class="card stat">
            <p class="muted small">Stock Bajo</p>
            <p class="stat-value danger">5</p>
          </div>
        </div>
        <div class="toolbar">
          <input type="text" class="input" placeholder="Buscar por ID, nombre o código..." />
          <select class="input">
            <option>Todas las categorías</option>
            <option>Platillo Principal</option>
            <option>Guarnición</option>
            <option>Ensaladas</option>
            <option>Postres</option>
            <option>Bebidas</option>
          </select>
          <select class="input">
            <option>Todos los niveles</option>
            <option>Stock Alto (&gt;50%)</option>
            <option>Stock Bajo (20-50%)</option>
            <option>Crítico (&lt;=20%)</option>
          </select>
        </div>
        <div class="card table-card">
          <table class="table">
            <thead>
              <tr>
                <th>Código</th>
                <th>Producto</th>
                <th>Categoría</th>
                <th>Disponible</th>
                <th>Capacidad</th>
                <th>Estado</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>P-001</td>
                <td>Arroz con Pollo</td>
                <td>Platillo Principal</td>
                <td>15</td>
                <td>30</td>
                <td><span class="badge badge-ok">Normal</span></td>
              </tr>
              <tr>
                <td>P-010</td>
                <td>Flan Casero</td>
                <td>Postres</td>
                <td>4</td>
                <td>20</td>
                <td><span class="badge badge-danger">Crítico</span></td>
              </tr>
            </tbody>
          </table>
        </div>
      </section>

      <!-- Warehouse -->
      <section class="page" id="warehouse">
        <div class="page-header-row">
          <h3>Gestión de Almacén</h3>
        </div>
        <div class="cards-grid-4">
          <div class="card stat">
            <p class="muted small">Total Insumos</p>
            <p class="stat-value">32</p>
          </div>
          <div class="card stat">
            <p class="muted small">Stock Alto</p>
            <p class="stat-value ok">18</p>
          </div>
          <div class="card stat">
            <p class="muted small">Stock Bajo</p>
            <p class="stat-value danger">6</p>
          </div>
          <div class="card stat">
            <p class="muted small">Categorías</p>
            <p class="stat-value">5</p>
          </div>
        </div>
        <div class="toolbar">
          <input type="text" class="input" placeholder="Buscar por ID o nombre..." />
          <select class="input">
            <option>Todas las categorías</option>
            <option>Granos</option>
            <option>Carnes</option>
            <option>Vegetales</option>
            <option>Lácteos</option>
            <option>Otros</option>
          </select>
          <select class="input">
            <option>Todos los niveles</option>
            <option>Stock Alto (&gt;50%)</option>
            <option>Stock Bajo (20-50%)</option>
            <option>Crítico (&lt;=20%)</option>
          </select>
        </div>
        <div class="card table-card">
          <table class="table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Ingrediente</th>
                <th>Categoría</th>
                <th>Cantidad</th>
                <th>Capacidad</th>
                <th>Estado</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>ING-001</td>
                <td>Arroz</td>
                <td>Granos</td>
                <td>20 kg</td>
                <td>50 kg</td>
                <td><span class="badge badge-ok">Normal</span></td>
              </tr>
              <tr>
                <td>ING-010</td>
                <td>Pechuga de Pollo</td>
                <td>Carnes</td>
                <td>5 kg</td>
                <td>40 kg</td>
                <td><span class="badge badge-danger">Crítico</span></td>
              </tr>
            </tbody>
          </table>
        </div>
      </section>

      <!-- Reports -->
      <section class="page" id="reports">
        <div class="page-header-row">
          <h3>Reportes y Análisis</h3>
          <select class="input small-input">
            <option>Últimos 7 días</option>
            <option>Últimos 30 días</option>
            <option>Últimos 90 días</option>
          </select>
        </div>
        <div class="cards-grid-3">
          <div class="card stat">
            <p class="muted small">Ventas Totales</p>
            <p class="stat-value">₡560 000</p>
            <p class="muted tiny">Últimos 7 días</p>
          </div>
          <div class="card stat">
            <p class="muted small">Dinero por Cupones</p>
            <p class="stat-value">₡120 000</p>
            <p class="muted tiny">Período seleccionado</p>
          </div>
          <div class="card stat">
            <p class="muted small">Devoluciones</p>
            <p class="stat-value danger">3</p>
            <p class="muted tiny">Órdenes devueltas</p>
          </div>
        </div>
        <div class="page-two-cols">
          <div class="card">
            <h4>Productos más vendidos</h4>
            <ul class="simple-list">
              <li>Casado Tradicional — 80 unidades</li>
              <li>Hamburguesa de la Casa — 65 unidades</li>
              <li>Jugo Natural de Naranja — 60 unidades</li>
            </ul>
          </div>
          <div class="card">
            <h4>Ventas por método de pago</h4>
            <ul class="simple-list">
              <li>Efectivo — ₡210 000</li>
              <li>Tarjeta — ₡230 000</li>
              <li>Cupón — ₡120 000</li>
            </ul>
          </div>
        </div>
      </section>

      <!-- Settings -->
      <section class="page" id="settings">
        <div class="card">
          <h3>Configuración</h3>
          <p class="muted">
            Aquí puedes simular ajustes generales del sistema. Como esta es una versión estática,
            los cambios no se guardan, pero puedes usarla como maqueta visual.
          </p>
          <form class="form-grid">
            <label>
              Nombre del Punto de Venta
              <input type="text" class="input" placeholder="Comedor Universitario" />
            </label>
            <label>
              Moneda
              <select class="input">
                <option>Colón Costarricense (₡)</option>
                <option>Dólar (USD)</option>
              </select>
            </label>
            <label>
              Tipo de cliente por defecto
              <select class="input">
                <option>Estudiante</option>
                <option>Funcionario</option>
                <option>Externo</option>
              </select>
            </label>
            <button type="button" class="btn-primary">Guardar (solo visual)</button>
          </form>
        </div>
      </section>
    </main>
  </div>

  <!-- Modal simple de Checkout (visual) -->
  <div class="modal-backdrop" id="checkout-modal">
    <div class="modal">
      <h3>Procesar Pago</h3>
      <p class="muted small">Versión simplificada del CheckoutDialog.</p>
      <label>
        Método de pago
        <select class="input">
          <option>Tarjeta</option>
          <option>Efectivo</option>
          <option>Cupón</option>
        </select>
      </label>
      <label>
        Monto recibido (si aplica)
        <input type="number" class="input" />
      </label>
      <div class="modal-actions">
        <button class="btn-ghost" id="close-checkout">Cancelar</button>
        <button class="btn-primary">Confirmar (demo)</button>
      </div>
    </div>
  </div>

  <!-- Modal simple de Nueva Orden (visual) -->
  <div class="modal-backdrop" id="order-modal">
    <div class="modal">
      <h3>Nueva Orden de Producción</h3>
      <p class="muted small">Versión estática del formulario de creación.</p>
      <label>
        Plato / Preparación
        <input type="text" class="input" placeholder="Ej: Casado Tradicional" />
      </label>
      <label>
        Cantidad esperada
        <input type="number" class="input" placeholder="Ej: 40" />
      </label>
      <div class="modal-actions">
        <button class="btn-ghost" id="close-order">Cancelar</button>
        <button class="btn-primary">Crear (demo)</button>
      </div>
    </div>
  </div>

  <script src="<?php echo BASE_URL; ?>/script.js"></script>
</body>
</html>
