<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Registro de Usuario</title>
</head>
<body>
    <h1>Crear Nuevo Usuario</h1>

    <?php 
    // Muestra errores de validación
    if (isset($errors) && !empty($errors)): ?>
        <p style="color: red;">❌ Error: <?php echo htmlspecialchars($errors); ?></p>
    <?php endif; ?>

    <form action="/user/store" method="POST">
        <div>
            <label for="nombre_usuario">Usuario (*):</label>
            <input type="text" id="nombre_usuario" name="nombre_usuario" required>
        </div>
        <div>
            <label for="password">Contraseña (*):</label>
            <input type="password" id="password" name="password" required>
        </div>
        <div>
            <label for="nombre">Nombre:</label>
            <input type="text" id="nombre" name="nombre">
        </div>
        <div>
            <label for="apellido">Apellido:</label>
            <input type="text" id="apellido" name="apellido">
        </div>
        <div>
            <label for="correo">Correo:</label>
            <input type="email" id="correo" name="correo">
        </div>
        
        <button type="submit">Registrar</button>
    </form>
    
    <p>¿Ya tienes cuenta? <a href="/login">Iniciar Sesión</a></p>
</body>
</html>
