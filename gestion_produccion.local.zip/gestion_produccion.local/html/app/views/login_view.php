<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Iniciar Sesión</title>
</head>
<body>
    <h1>Acceso al Sistema</h1>

    <?php 
    // 1. Muestra mensajes de ÉXITO de registro (Mensaje Flash de Sesión)
    if (isset($_SESSION['register_success'])): ?>
        <p style="color: green; border: 1px solid green; padding: 10px;">
            ✅ **<?php echo htmlspecialchars($_SESSION['register_success']); ?>**
        </p>
        <?php unset($_SESSION['register_success']); // Borra el mensaje después de mostrarlo ?>
    <?php endif; ?>
    
    <?php 
    // 2. Muestra mensajes de ERROR de autenticación (Definido en el Controlador)
    if (isset($error_message) && !empty($error_message)): ?>
        <p style="color: red; border: 1px solid red; padding: 10px;">
            ⚠️ **ERROR:** <?php echo htmlspecialchars($error_message); ?>
        </p>
    <?php endif; ?>

    <form action="/authenticate" method="POST">
        <div>
            <label for="username">Usuario:</label>
            <input type="text" id="username" name="username" required>
        </div>
        <div>
            <label for="password">Contraseña:</label>
            <input type="password" id="password" name="password" required>
        </div>
        <button type="submit">Iniciar Sesión</button>
    </form>
    
    <hr>
    
    <p>¿No tienes una cuenta?</p>
    <p>
        <a href="/register">**¡Regístrate aquí para crear una!**</a> 👈
    </p>
</body>
</html>
