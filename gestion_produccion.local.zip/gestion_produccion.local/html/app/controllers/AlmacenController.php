<?php
// app/controllers/AlmacenController.php

// Asegura que la ruta a Database.php sea correcta
require_once dirname(__DIR__, 2) . '/app/core/Database.php'; 
require_once __DIR__ . '/../models/AlmacenModel.php'; 

class AlmacenController {
    private $almacenModel;

    public function __construct() {
        // Obtiene la conexión PDO usando tu clase Database
        $dbConnection = Database::getInstance()->getConnection(); 
        $this->almacenModel = new AlmacenModel($dbConnection);
    }
    
    // --- Acción por defecto: Mostrar el inventario ---
    public function index() {
        // 1. Obtener los datos del inventario
        $inventario = $this->almacenModel->getInventarioCompleto();
        
        // 2. Preparar los datos para la vista
        $data = [
            'titulo' => 'Inventario de Almacén',
            'inventario' => $inventario
        ];
        
        // 3. Renderizar la vista
        // Asumiendo que tienes una función para incluir vistas, ej: View::render('almacen/index', $data);
        
        // Por ahora, solo imprime para depuración o prueba API:
        header('Content-Type: application/json');
        echo json_encode($data);
    }
    
    // --- Acción para procesar el formulario de entrada de stock (Registro de Compras) ---
    public function registrarEntrada() {
        // 1. Solo procesamos peticiones POST
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            
            // 2. Recolección y validación de datos
            $id_inventario = filter_input(INPUT_POST, 'id_inventario', FILTER_VALIDATE_INT);
            $cantidad = filter_input(INPUT_POST, 'cantidad', FILTER_VALIDATE_FLOAT);
            $observacion = filter_input(INPUT_POST, 'observacion', FILTER_SANITIZE_STRING);
            
            // Asume que el ID de usuario está en la sesión, si no, usa un valor por defecto (ej: 1)
            $usuario_id = $_SESSION['user_id'] ?? 1; 
            // El ID de área 1 es 'Bodega Principal' según tu SQL
            $id_area_bodega = 1; 

            if ($id_inventario && $cantidad > 0) {
                // 3. Llamar al modelo para registrar la entrada
                $success = $this->almacenModel->registrarEntradaStock($id_inventario, $cantidad, $usuario_id, $id_area_bodega, $observacion);
                
                // 4. Manejo de respuesta
                if ($success) {
                    // Se usa header Location para el patrón Post-Redirect-Get (PRG)
                    header("Location: /warehouse?status=entrada_ok");
                    exit;
                } else {
                    header("Location: /warehouse?status=error&msg=Fallo_al_registrar_entrada");
                    exit;
                }
            }
        }
        // Si no es POST, redirige a la vista principal del almacén.
        header("Location: /warehouse");
    }
}