<?php
// app/controllers/ReportesController.php

require_once __DIR__ . '/../core/Database.php'; 
require_once __DIR__ . '/../models/ReportesModel.php'; 

class ReportesController {
    private $reportesModel;

    public function __construct() {
        $dbConnection = Database::getInstance()->getConnection(); 
        $this->reportesModel = new ReportesModel($dbConnection);
    }
    
    // Acción por defecto: Mostrar la página principal de selección de reportes
    public function index() {
        $data = [
            'titulo' => 'Selección de Reportes',
            'reportes_disponibles' => [
                'ventas' => 'Resumen de Ventas por Período',
                'critico' => 'Inventario con Stock Crítico'
            ]
        ];
        
        // Renderizar la vista principal de reportes (ej: reports/index.php)
        header('Content-Type: application/json');
        echo json_encode(['data' => $data]);
    }
    
    // Acción para generar y mostrar el reporte de ventas
    public function ventas() {
        // Asumimos que las fechas se reciben por GET o POST
        $fecha_inicio = $_REQUEST['inicio'] ?? date('Y-m-01'); // Inicio del mes actual
        $fecha_fin = $_REQUEST['fin'] ?? date('Y-m-d');     // Hoy

        $reporte = $this->reportesModel->getResumenVentas($fecha_inicio, $fecha_fin);

        // Renderizar la vista específica o retornar los datos
        header('Content-Type: application/json');
        echo json_encode([
            'success' => true,
            'reporte' => $reporte,
            'periodo' => ['inicio' => $fecha_inicio, 'fin' => $fecha_fin]
        ]);
    }
    
    // Acción para generar y mostrar el reporte de inventario crítico
    public function critico() {
        $reporte = $this->reportesModel->getInventarioCritico();

        // Renderizar la vista específica o retornar los datos
        header('Content-Type: application/json');
        echo json_encode([
            'success' => true,
            'reporte' => $reporte
        ]);
    }
}