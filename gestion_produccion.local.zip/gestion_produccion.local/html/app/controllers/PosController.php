<?php
// CRÍTICO: Asegúrese de que estas rutas sean las correctas.
require_once __DIR__ . '/../core/Database.php'; 
die("Punto A: Archivos cargados correctamente.");
// VentaModel.php está en '../models/'
require_once __DIR__ . '/../models/VentaModel.php';

class PosController {
    private $ventaModel;

    public function __construct() {
        // Inicializar el Modelo con la conexión a la DB
        $dbConnection = Database::getInstance()->getConnection(); 
        $this->ventaModel = new VentaModel($dbConnection);
        
        // **IMPORTANTE:** Iniciar la sesión aquí si no lo haces en el index.php
        if (session_status() == PHP_SESSION_NONE) {
            session_start();
        }
    }
    
    // --- Lógica del Carrito ---

    /**
     * Helper: Devuelve el resumen del carrito (para la respuesta JSON)
     */
    private function getCartSummary() {
        $summary = ['items' => [], 'count' => 0, 'total' => 0];
        if (isset($_SESSION['cart'])) {
            $summary['items'] = array_values($_SESSION['cart']); 
            foreach ($summary['items'] as $item) {
                $summary['count'] += $item['qty'];
                $summary['total'] += $item['subtotal'];
            }
        }
        return $summary;
    }

    /**
     * Helper: Envía respuesta JSON al frontend y termina la ejecución
     */
    private function sendJson($data) {
        header('Content-Type: application/json');
        echo json_encode($data);
        exit;
    }

    // --- Endpoints AJAX ---

    /**
     * Endpoint: BASE_URL/pos/add
     */
    public function add() {
        $data = json_decode(file_get_contents('php://input'), true);
        $receta_id = $data['product_id']; 
        $quantity = $data['quantity'];
        
        // 1. Consultar la DB usando el Modelo
        $details = $this->ventaModel->getRecetaDetails($receta_id);
        
        if (!$details) {
            $this->sendJson(['success' => false, 'message' => 'Receta no encontrada.']);
        }
        
        // 2. Guardar en SESIÓN (Carrito Temporal)
        if (!isset($_SESSION['cart'])) $_SESSION['cart'] = [];

        $_SESSION['cart'][$receta_id] = [
            'id' => $receta_id, 
            'id_receta_historico' => $details['id_receta_historico'],
            'name' => $details['nombre_receta'],
            'price' => (float)$details['precio_venta'],
            'qty' => $quantity,
            'subtotal' => (float)$details['precio_venta'] * $quantity
        ];

        $this->sendJson(['success' => true, 'cart' => $this->getCartSummary()]);
    }
    
    /**
     * Endpoint: BASE_URL/pos/clear
     */
    public function clear() {
        unset($_SESSION['cart']);
        $this->sendJson(['success' => true, 'cart' => $this->getCartSummary()]);
    }
    
    // =======================================================
    // NUEVO ENDPOINT: REMOVER ÍTEM
    // =======================================================
    /**
     * Endpoint: BASE_URL/pos/remove-item
     * Elimina un producto específico del carrito (Sesión).
     */
    public function remove_item() {
        $data = json_decode(file_get_contents('php://input'), true);
        $item_id = $data['item_id']; // item_id es el receta_id

        if (isset($_SESSION['cart'][$item_id])) {
            unset($_SESSION['cart'][$item_id]); // Eliminar el ítem de la sesión
            $this->sendJson(['success' => true, 'message' => 'Artículo eliminado.', 'cart' => $this->getCartSummary()]);
        } else {
            $this->sendJson(['success' => false, 'message' => 'El artículo no se encontró en el carrito.', 'cart' => $this->getCartSummary()]);
        }
    }
    // =======================================================

    /**
     * Endpoint: BASE_URL/pos/checkout
     */
    public function checkout() {
        $data = json_decode(file_get_contents('php://input'), true);
        $tipo_pago = $data['payment_method'] ?? 'Efectivo';
        
        if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
            $this->sendJson(['success' => false, 'message' => 'El carrito está vacío.']);
        }
        
        $cartSummary = $this->getCartSummary();
        $cajero_id = $_SESSION['user_id'] ?? 1; // Usar ID 1 por defecto si no hay sesión de usuario

        $result = $this->ventaModel->finalizeSale($cajero_id, $tipo_pago, $cartSummary['items'], $cartSummary['total']);
        
        if ($result) {
            unset($_SESSION['cart']); 
            $this->sendJson(['success' => true, 'message' => 'Venta registrada.', 'cart' => $this->getCartSummary()]);
        } else {
            $this->sendJson(['success' => false, 'message' => 'Error al registrar la venta.']);
        }
    }
}