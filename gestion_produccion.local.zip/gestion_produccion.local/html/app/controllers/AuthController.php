<?php
// app/controllers/AuthController.php

// Iniciar sesión (si no está iniciada), necesario para $_SESSION
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Ruta al Modelo: Sube un nivel (../) desde 'controllers'
require_once __DIR__ . '/../models/UserModel.php';
// Ruta a la Configuración (necesaria para BASE_URL): Sube dos niveles (../../)
require_once __DIR__ . '/../../config/dbConfig.php';

class AuthController {
    
    // Muestra la vista de login (app/views/login_view.php)
    public function login() {
        // $error_message se define solo si venimos de un fallo
        require_once __DIR__ . '/../views/login_view.php';
    }

    // Procesa la autenticación (recibe el POST del formulario)
    public function authenticate() {
        $error_message = '';

        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            
            $username = $_POST['username'] ?? '';
            $password = $_POST['password'] ?? '';

            $userModel = new UserModel();
            $user = $userModel->findByUsername($username); // Llama al método del modelo

            // 1. Verificar si el usuario existe Y está activo (asumiendo activo=1)
            if ($user && $user['activo'] == 1) {
                
                // 2. Verificar la contraseña hasheada
                if (password_verify($password, $user['password_hash'])) {
                    
                    // --- Autenticación Exitosa ---
                    $_SESSION['user_id'] = $user['id_usuario'];
                    $_SESSION['username'] = $user['nombre_usuario'];
                    
                    header('Location: ' . BASE_URL . '/dashboard');
                    exit();
                    
                } else {
                    // Contraseña incorrecta (falla password_verify)
                    $error_message = 'Contraseña incorrecta.';
                }
            } else {
                // Usuario no encontrado o inactivo
                $error_message = 'Credenciales de acceso incorrectas o usuario inactivo.'; 
            }

            // Si hay un error, vuelve a cargar la vista con el mensaje de error.
            require_once __DIR__ . '/../views/login_view.php';
            
        } else {
            // Si alguien intenta acceder directamente a /authenticate, redirigir al login
            header('Location: ' . BASE_URL . '/login');
            exit();
        }
    }

    // Muestra el dashboard (ruta protegida)
    public function dashboard() {
        // Protección de sesión
        if (!isset($_SESSION['user_id'])) {
            header('Location: ' . BASE_URL . '/login');
            exit();
        }

        // Datos para la vista
        $username = $_SESSION['username'];
        require_once __DIR__ . '/../views/dashboard_view.php';
    }

    // Cierra la sesión
    public function logout() {
        session_destroy(); 
        header('Location: ' . BASE_URL . '/login');
        exit();
    }

    public function register() {
        // La variable $errors puede usarse para mostrar errores de validación
        require_once __DIR__ . '/../views/register_view.php';
    }

    /**
     * Procesa la inserción del nuevo usuario (Ruta: /user/store)
     */
    public function store() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            
            $nombre_usuario = $_POST['nombre_usuario'] ?? '';
            $nombre         = $_POST['nombre'] ?? '';
            $apellido       = $_POST['apellido'] ?? '';
            $correo         = $_POST['correo'] ?? '';
            $password       = $_POST['password'] ?? '';
            
            // 1. VALIDACIÓN BÁSICA (Añadir aquí más validaciones si es necesario)
            if (empty($nombre_usuario) || empty($password)) {
                $errors = "Todos los campos obligatorios deben ser llenados.";
                require_once __DIR__ . '/../views/register_view.php';
                return;
            }

            // 2. HASHEAR LA CONTRASEÑA antes de enviarla al Modelo
            $password_hash = password_hash($password, PASSWORD_DEFAULT);

            // 3. LLAMAR AL MODELO
            $userModel = new UserModel();
            
            // CAPTURAR EL RESULTADO DEL MODELO (TRUE, 'duplicate', o FALSE)
            $result = $userModel->createUser($nombre_usuario, $nombre, $apellido, $correo, $password_hash);
            
            if ($result === true) {
                // Éxito
                $_SESSION['register_success'] = "¡Registro Exitoso! Ahora puedes iniciar sesión.";

                // *** MODIFICACIÓN 1: Redirigir al login después de un registro exitoso ***
                header('Location: ' . BASE_URL . '/login'); 
                exit();
            } else {
                // MANEJO ESPECÍFICO DE ERRORES (mantiene la lógica de error)
                if ($result === 'duplicate') {
                    // Falló por la restricción UNIQUE (nombre de usuario o correo)
                    $errors = "Error: El nombre de usuario o correo ya están registrados. Por favor, elija otros.";
                } else {
                    // Falló por otra razón (ej: campo NOT NULL vacío, error de sintaxis en el INSERT)
                    $errors = "Error desconocido de la base de datos.";
                }
                
                require_once __DIR__ . '/../views/register_view.php';
            }
        } else {
            header('Location: ' . BASE_URL . '/register');
        }
    }
}
?>