<?php
// CRÍTICO: Asegúrese de que esta ruta sea la correcta para alcanzar db_config.php
require_once __DIR__ . '/../config/db_config.php'; 

class Database {
    private static $instance = null;
    private $connection;

    private function __construct() {
        // Estableciendo el DSN (Data Source Name) para MySQL con PDO
        $dsn = "mysql:host=" . DB_SERVERNAME . ";dbname=" . DB_NAME . ";charset=utf8mb4";
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];

        try {
            // Conexión real a MySQL usando las constantes de db_config.php
            $this->connection = new PDO($dsn, DB_USERNAME, DB_PASSWORD, $options);
            
        } catch (PDOException $e) {
            // Detener la ejecución si la conexión falla (IMPORTANTE: para desarrollo)
            die("Error Fatal de Conexión a MySQL: " . $e->getMessage());
        }
    }

    public static function getInstance() {
        if (!self::$instance) {
            self::$instance = new Database();
        }
        return self::$instance;
    }

    public function getConnection() {
        return $this->connection;
    }
}
// Ahora puedes obtener la conexión PDO en cualquier lugar: 
// $db = Database::getInstance()->getConnection();