document.addEventListener("DOMContentLoaded", () => {
    // =======================================================
    // 1. LÓGICA DE NAVEGACIÓN Y MODALES (Mantenida)
    // =======================================================
    const navItems = document.querySelectorAll(".nav-item");
    const pages = document.querySelectorAll(".page");
    const title = document.getElementById("page-title");
    const pageTitles = {
        home: "Inicio",
        pos: "Punto de Venta",
        orders: "Pedidos (Cocina)",
        prepared: "Preparados",
        warehouse: "Almacén",
        reports: "Reportes",
        settings: "Configuración",
    };

    function showPage(id) {
        pages.forEach((p) => p.classList.remove("visible"));
        const target = document.getElementById(id);
        if (target) target.classList.add("visible");
        if (title && pageTitles[id]) {
            title.textContent = pageTitles[id];
        }
    }

    navItems.forEach((btn) => {
        btn.addEventListener("click", () => {
            navItems.forEach((b) => b.classList.remove("active"));
            btn.classList.add("active");
            const target = btn.getAttribute("data-target");
            if (target) showPage(target);
        });
    });

    const checkoutModal = document.getElementById("checkout-modal");
    const orderModal = document.getElementById("order-modal");

    // Modals - Abriendo/Cerrando
    document.getElementById("checkout-btn")?.addEventListener("click", () => {
        checkoutModal?.classList.add("visible");
    });
    document.getElementById("close-checkout")?.addEventListener("click", () => {
        checkoutModal?.classList.remove("visible");
    });
    document.getElementById("new-order-btn")?.addEventListener("click", () => {
        orderModal?.classList.add("visible");
    });
    document.getElementById("close-order")?.addEventListener("click", () => {
        orderModal?.classList.remove("visible");
    });
    
    // Al cargar la página, mostrar inicio
    showPage("home");


    // =======================================================
    // 2. FUNCIONES BASE PARA AJAX Y RENDERIZADO
    // =======================================================
    
    // Elementos del carrito para actualizar
    const cartBody = document.querySelector(".cart-body");
    const cartBadge = document.querySelector(".cart-card .badge");
    const cartTotal = document.querySelector(".cart-total");

    /**
     * Helper: Realiza una petición POST al controlador PHP.
     * @param {string} endpoint - La ruta del controlador (ej: /pos/add).
     * @param {object} data - Los datos a enviar.
     */
    async function postData(endpoint, data) {
        try {
            // Usamos la ruta completa, el front controller la manejará
            const response = await fetch(endpoint, { 
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data),
            });
            // Si la respuesta no es JSON (ej: un error 404 del servidor), manejarlo.
            if (!response.ok) {
                 throw new Error(`Error HTTP: ${response.status}`);
            }
            return response.json();
        } catch (error) {
            console.error('Error en la petición:', error);
            alert(`Error de comunicación: ${error.message}. Revise la consola.`);
            return { success: false, message: 'Fallo de red o servidor.' };
        }
    }

    /** * RENDERIZA: Actualiza el HTML del carrito con los datos de PHP.
     * @param {object} cartData - Objeto con el estado completo del carrito.
     */
    function renderCart(cartData) {
        if (!cartData || !cartBody) return;

        // Limpiar el contenido actual
        cartBody.innerHTML = ''; 

        // Rellenar con los ítems actualizados
        cartData.items.forEach(item => {
            const subtotalFormatted = item.subtotal.toLocaleString('es-CR');
            const priceFormatted = item.price.toLocaleString('es-CR');
            const itemHTML = `
                <div class="cart-item" data-cart-item-id="${item.id}">
                    <div>
                        <p>${item.name}</p>
                        <p class="muted small">${item.qty} x ₡${priceFormatted}</p>
                    </div>
                    <div class="cart-item-right">
                        <span>₡${subtotalFormatted}</span>
                        <button class="icon-btn delete-cart-item" data-item-id="${item.id}">🗑️</button>
                    </div>
                </div>
            `;
            cartBody.insertAdjacentHTML('beforeend', itemHTML);
        });

        // Actualizar totales y contador
        const totalFormatted = cartData.total.toLocaleString('es-CR');
        cartBadge.textContent = `${cartData.count} artículos`;
        cartTotal.textContent = `₡${totalFormatted}`;
    }
    
    // =======================================================
    // 3. LÓGICA FUNCIONAL DEL PUNTO DE VENTA
    // =======================================================

    // A. Control de Cantidad (+/-)
    document.querySelectorAll(".product-card .qty-row button").forEach(button => {
        button.addEventListener("click", (e) => {
            const card = e.target.closest(".product-card");
            const qtyDisplay = card.querySelector(".qty-display");
            let currentQty = parseInt(qtyDisplay.textContent);
            const action = e.target.getAttribute("data-action"); // Usar el atributo data-action que definimos antes

            if (action === "increment") {
                currentQty++;
            } else if (action === "decrement" && currentQty > 0) {
                currentQty--;
            }
            qtyDisplay.textContent = currentQty;
        });
    });

    // B. "Agregar al pedido" (Llamada AJAX a /pos/add)
    document.querySelectorAll(".product-card").forEach(card => {
        const addButton = card.querySelector(".btn-primary.full-width");
        const qtyDisplay = card.querySelector(".qty-display");

        addButton?.addEventListener("click", async () => {
            const productId = card.getAttribute("data-product-id");
            const quantity = parseInt(qtyDisplay.textContent);
            
            if (!productId || quantity <= 0) return; 

            // Llamada al controlador PHP
            const result = await postData('/pos/add', { product_id: productId, quantity: quantity });
            
            if (result.success) {
                renderCart(result.cart);
                qtyDisplay.textContent = '0'; // Resetear el contador local tras añadir
            } else {
                alert(`Error al añadir: ${result.message}`);
            }
        });
    });

    // C. "Limpiar Carrito" (Llamada AJAX a /pos/clear)
    const clearCartBtn = document.getElementById("clear-cart-btn");
    if (clearCartBtn) {
        clearCartBtn.addEventListener("click", async () => {
            if (!confirm("¿Confirma que desea vaciar el pedido?")) return;

            const result = await postData('/pos/clear', {});
            
            if (result.success) {
                renderCart(result.cart); // renderCart con carrito vacío
                document.querySelectorAll(".qty-display").forEach(display => {
                    display.textContent = '0';
                });
            } else {
                alert(`Error al limpiar el carrito: ${result.message}`);
            }
        });
    }

    // D. "Confirmar (Cobrar)" en el Modal (Llamada AJAX a /pos/checkout)
    const confirmCheckoutBtn = checkoutModal ? checkoutModal.querySelector(".modal-actions .btn-primary") : null;
    const paymentMethodSelect = checkoutModal ? checkoutModal.querySelector("select") : null;

    if (confirmCheckoutBtn && paymentMethodSelect) {
        confirmCheckoutBtn.addEventListener("click", async () => {
            // Deshabilitar botón para evitar doble click
            confirmCheckoutBtn.disabled = true;
            confirmCheckoutBtn.textContent = 'Procesando...';

            const data = {
                payment_method: paymentMethodSelect.value,
                // Puedes añadir aquí el monto recibido, cambio, etc.
            };

            const result = await postData('/pos/checkout', data);
            
            // Revertir estado del botón
            confirmCheckoutBtn.disabled = false;
            confirmCheckoutBtn.textContent = 'Confirmar';

            if (result.success) {
                alert(`Venta exitosa: ${result.message}`);
                checkoutModal.classList.remove("visible"); // Cerrar modal
                renderCart(result.cart); // El carrito estará vacío
            } else {
                alert(`Error al cobrar: ${result.message}`);
            }
        });
    }
    
    // E. Eliminar Ítem del carrito (Delegación de eventos en el cuerpo del carrito)
    if (cartBody) {
        cartBody.addEventListener("click", async (e) => {
            // Verificar si el clic fue en el botón de borrar
            const deleteButton = e.target.closest(".delete-cart-item");
            if (deleteButton) {
                const itemId = deleteButton.getAttribute("data-item-id");
                
                if (!confirm("¿Desea eliminar este artículo del pedido?")) return;

                const data = { item_id: itemId };
                // CRÍTICO: Debes implementar este endpoint en tu PosController.php
                const result = await postData('/pos/remove-item', data); 
                
                if (result.success) {
                    renderCart(result.cart);
                } else {
                    alert(`Error al eliminar: ${result.message || 'Desconocido'}`);
                }
            }
        });
    }

});