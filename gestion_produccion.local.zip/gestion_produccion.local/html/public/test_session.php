<?php
header('Content-Type: text/plain; charset=UTF-8');
session_start();

// Si no existe un contador, crear
if (!isset($_SESSION['counter'])) {
    $_SESSION['counter'] = 0;
}
$_SESSION['counter']++;

echo "Session id: " . session_id() . PHP_EOL;
echo "Session save path: " . ini_get('session.save_path') . PHP_EOL;
echo "Session counter: " . $_SESSION['counter'] . PHP_EOL;
echo "Cookie params: " . print_r(session_get_cookie_params(), true) . PHP_EOL;
echo "Superglobals:\n";
echo "_COOKIE: " . print_r($_COOKIE, true) . PHP_EOL;
echo "_SESSION: " . print_r($_SESSION, true) . PHP_EOL;
