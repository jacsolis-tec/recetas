<?php
// public/index.php (Front Controller - VERSIÓN FINAL)

// 🚨 IMPORTANTE: Habilitar errores para debugging (QUITAR EN PRODUCCIÓN)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// INICIAR SESIÓN GLOBALMENTE
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// =======================================================
// 1. INCLUSIÓN DE CONTROLADORES (RUTA CORREGIDA Y COMPLETA)
// =======================================================
require_once __DIR__ . '/../app/controllers/AuthController.php';

// =======================================================
// 2. PROCESAMIENTO DE URI Y CORRECCIÓN DE BASE (¡SOLUCIÓN 404!)
// =======================================================

/**
 * ⚠️ CRÍTICO: Define la base del proyecto para limpiar la URI.
 * EJEMPLO: Si la URL es http://[IP]/gestion_produccion/public/dashboard
 * La base es: 'gestion_produccion/public'
 */
$base_path_to_remove = 'gestion_produccion/public'; 

$uri = trim(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH), '/');

// Limpiar la URI: Elimina la base del proyecto.
if (!empty($base_path_to_remove)) {
    // Reemplaza la base al inicio de la URI capturada.
    $uri = str_replace($base_path_to_remove, '', $uri);
}

// Asegura que no queden barras extras al inicio o final
$uri = trim($uri, '/'); 

$segments = explode('/', $uri);

$controller_name = array_shift($segments);
$action_name = array_shift($segments);

// =======================================================
// 3. ENRUTAMIENTO PRINCIPAL (SWITCH COMPLETO)
// =======================================================

// Si la URL es la raíz, redirigir a login
if (empty($controller_name)) {
    $controller_name = 'login';
}

switch ($controller_name) {
    
    // --- Rutas de PUNTO DE VENTA (POS) ---
    case 'pos':
        $controller = new PosController();
        // Usar 'index' como acción por defecto si no se especifica
        $action = $action_name ?: 'index'; 

        if (method_exists($controller, $action)) {
            $controller->$action();
        } else {
            header("HTTP/1.0 404 Not Found");
            echo "<h1>404 Not Found</h1><p>Acción de POS ($action) no encontrada.</p>";
        }
        break;

    // --- Rutas del MÓDULO ALMACÉN/INVENTARIO ---
    case 'almacen':
    case 'warehouse':
        $controller = new AlmacenController();
        $action = $action_name ?: 'index'; 

        if (method_exists($controller, $action)) {
            $controller->$action();
        } else {
            header("HTTP/1.0 404 Not Found");
            echo "<h1>404 Not Found</h1><p>Acción de Almacén ($action) no encontrada.</p>";
        }
        break;
        
    // --- Rutas del MÓDULO REPORTES ---
    case 'reports':
        $controller = new ReportesController();
        $action = $action_name ?: 'index'; 

        if (method_exists($controller, $action)) {
            $controller->$action();
        } else {
            header("HTTP/1.0 404 Not Found");
            echo "<h1>404 Not Found</h1><p>Acción de Reportes ($action) no encontrada.</p>";
        }
        break;
        
    // --- Rutas de AUTENTICACIÓN Y VISTAS ---
    case 'login':
    case 'authenticate':
    case 'register':
    case 'user':
    case 'dashboard':
    case 'logout':
        $controller = new AuthController();
        
        $action = $controller_name;
        if ($controller_name === 'user') {
            $action = $action_name;
        }
        
        if (method_exists($controller, $action)) {
            $controller->$action();
        } else {
            header("HTTP/1.0 404 Not Found");
            echo "<h1>404 Not Found</h1><p>Acción de Autenticación no encontrada.</p>";
        }
        break;
    
    // 6. Manejo de Rutas No Encontradas
    default:
        header("HTTP/1.0 404 Not Found");
        echo "<h1>404 Not Found</h1><p>La página solicitada ($controller_name) no existe.</p>";
        break;
}