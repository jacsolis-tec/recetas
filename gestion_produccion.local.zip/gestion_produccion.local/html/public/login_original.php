<?php
session_start();

// Si ya está logueado → al dashboard
if (!empty($_SESSION['logged_in'])) {
    header("Location: /index.php");
    exit;
}

// Procesar el POST del login
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $user = $_POST['username'] ?? '';
    $pass = $_POST['password'] ?? '';

    // Validación mínima (ajústala a tu BD después)
    if ($user === 'admin' && $pass === '1234') {

        $_SESSION['logged_in'] = true;
        $_SESSION['username'] = $user;

        header("Location: /index.php");
        exit;

    } else {
        $error = "Usuario o contraseña incorrectos.";
    }
}

// mostrar la vista
require_once __DIR__ . '/../views/login_view.php';
