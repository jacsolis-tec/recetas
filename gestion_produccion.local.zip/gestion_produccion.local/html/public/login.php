<?php
session_start();
require_once __DIR__ . '/../models/UserModel.php';

$login_message = "";
$input_username = "";

// Si ya está logueado → index
if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
    header("Location: /public/index.html");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input_username = trim($_POST['username'] ?? '');
    $input_password = $_POST['password'] ?? '';

    if ($input_username === "" || $input_password === "") {
        $login_message = "❌ Por favor ingrese usuario y contraseña.";
    } else {
        $model = new UserModel();
        $result = $model->verify_credentials($input_username, $input_password);

        if ($result['success']) {
            session_regenerate_id(true);
            $_SESSION['logged_in'] = true;
            $_SESSION['user_id']   = $result['user']['id'];
            $_SESSION['username']  = $result['user']['username'];
            $_SESSION['full_name'] = $result['user']['full_name'];

            header("Location: /public/index.html");
            exit;
        } else {
            $login_message = $result['message'];
        }
    }
}

require_once __DIR__ . '/../views/login_view.php';
