<?php
// app/config/dbConfig.php

// *** VALORES DE CONEXIÓN ***
const DB_SERVERNAME = "localhost";
const DB_USERNAME = "bases";
const DB_PASSWORD = "Bases123."; 
const DB_NAME = "gestion_produccion";
const DB_TABLE_NAME = "usuario";

// SOLUCIÓN: Definir BASE_URL de forma dinámica
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
$host = $_SERVER['HTTP_HOST'];

// ⚠️ AJUSTAR ESTA RUTA según si usas Virtual Host o Subdirectorio:
// Si usas el subdirectorio 'gestion_produccion/public'
//$sub_directory = '/gestion_produccion/public'; 

// Si usas Virtual Host (ej: gestion_produccion.local)
 $sub_directory = ''; 

define('BASE_URL', $protocol . $host . $sub_directory); 
?>